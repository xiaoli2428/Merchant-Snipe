/**
 * AI P2P Merchant Bot Engine
 * ─────────────────────────────────────────────────────────────────────────────
 * Connects to any exchange via CCXT (unified crypto trading library),
 * monitors P2P order books, creates spread positions, matches trades,
 * and deposits profits into the ProfitVaultProtocol smart contract.
 *
 * Supports: Binance, OKX, Bybit, KuCoin, HTX, Gate.io, MEXC, Bitget,
 *           Kraken, Coinbase, Bitfinex, Phemex, and 100+ more via CCXT.
 *
 * Install:
 *   npm install ccxt ethers dotenv winston
 *
 * Usage:
 *   node merchant-bot.js --exchange binance --pair USDT/USD --spread 0.8
 */

"use strict";

const ccxt    = require("ccxt");
const ethers  = require("ethers");
const winston = require("winston");
require("dotenv").config();

// ─── Config ───────────────────────────────────────────────────────────────────

const CONFIG = {
  // Smart Contract (ProfitVaultProtocol)
  VAULT_CONTRACT:  process.env.VAULT_CONTRACT  || "0x7F3A9c2B4E1D8f56aC90bE3d12F47aE6C8b5D921",
  RPC_URL:         process.env.RPC_URL         || "https://bsc-dataseed.binance.org",
  OPERATOR_KEY:    process.env.OPERATOR_KEY,          // Bot wallet private key
  MERCHANT_ADDR:   process.env.MERCHANT_ADDR,         // Merchant wallet to credit

  // Exchange credentials (set per-exchange in .env)
  EXCHANGE_ID:     process.env.EXCHANGE_ID     || "binance",
  API_KEY:         process.env.EXCHANGE_API_KEY,
  API_SECRET:      process.env.EXCHANGE_API_SECRET,

  // Trading parameters
  PAIRS:           (process.env.PAIRS || "USDT/USD,BTC/USDT,ETH/USDT").split(","),
  SPREAD_PCT:      parseFloat(process.env.SPREAD_PCT || "0.8"),   // 0.8%
  MIN_ORDER_USD:   parseFloat(process.env.MIN_ORDER_USD || "50"),
  MAX_ORDER_USD:   parseFloat(process.env.MAX_ORDER_USD || "5000"),
  POLL_MS:         parseInt(process.env.POLL_MS || "2000"),

  // Risk management
  MAX_INVENTORY:   parseFloat(process.env.MAX_INVENTORY || "10000"),  // USD
  STOP_LOSS_PCT:   parseFloat(process.env.STOP_LOSS_PCT || "2.0"),
};

// ─── Vault ABI (minimal) ──────────────────────────────────────────────────────

const VAULT_ABI = [
  "function depositProfit(address merchant, address token, uint256 amount, uint256 spreadBps, string exchangeId, string pair, bytes32 txHash) external",
  "function depositNativeProfit(address merchant, uint256 spreadBps, string exchangeId, string pair, bytes32 txHash) external payable",
  "event ProfitDeposited(address indexed merchant, address indexed token, uint256 amount, uint256 fee, string exchangeId, string pair, uint256 spreadBps, uint256 indexed tradeId)",
];

const TOKEN_ABI = [
  "function approve(address spender, uint256 amount) external returns (bool)",
  "function allowance(address owner, address spender) external view returns (uint256)",
];

// Token addresses on BSC
const TOKEN_ADDRESSES = {
  "USDT": "0x55d398326f99059fF775485246999027B3197955",
  "USDC": "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d",
  "BTC":  "0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c",
  "ETH":  "0x2170Ed0880ac9A755fd29B2688956BD959F933F8",
  "BNB":  null,  // native
};

// ─── Logger ───────────────────────────────────────────────────────────────────

const logger = winston.createLogger({
  level: "info",
  format: winston.format.combine(
    winston.format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
    winston.format.colorize(),
    winston.format.printf(({ timestamp, level, message }) =>
      `[${timestamp}] ${level}: ${message}`
    )
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: "merchant-bot.log" }),
  ],
});

// ─── Merchant Bot Class ───────────────────────────────────────────────────────

class AIMerchantBot {
  constructor(exchangeId) {
    this.exchangeId  = exchangeId;
    this.exchange    = null;
    this.provider    = null;
    this.wallet      = null;
    this.vault       = null;
    this.isRunning   = false;
    this.inventory   = {};  // { symbol: amount }
    this.totalProfit = 0;
    this.tradeCount  = 0;
    this.openOrders  = new Map();
  }

  // ── Initialize ─────────────────────────────────────────────────────────────

  async init() {
    logger.info(`Initializing AI Merchant Bot on ${this.exchangeId.toUpperCase()}`);

    // Connect to exchange
    const ExchangeClass = ccxt[this.exchangeId];
    if (!ExchangeClass) throw new Error(`Exchange '${this.exchangeId}' not supported by CCXT`);

    this.exchange = new ExchangeClass({
      apiKey:    CONFIG.API_KEY,
      secret:    CONFIG.API_SECRET,
      enableRateLimit: true,
      options: { defaultType: "spot" },
    });

    await this.exchange.loadMarkets();
    logger.info(`Connected to ${this.exchange.name} — ${Object.keys(this.exchange.markets).length} markets loaded`);

    // Connect to blockchain
    this.provider = new ethers.JsonRpcProvider(CONFIG.RPC_URL);
    this.wallet   = new ethers.Wallet(CONFIG.OPERATOR_KEY, this.provider);
    this.vault    = new ethers.Contract(CONFIG.VAULT_CONTRACT, VAULT_ABI, this.wallet);

    const chainId = (await this.provider.getNetwork()).chainId;
    logger.info(`Wallet connected: ${this.wallet.address} | Chain ID: ${chainId}`);

    // Pre-approve vault for all tokens
    await this._approveTokens();

    logger.info("Bot initialized successfully");
  }

  // ── Approve tokens for vault ───────────────────────────────────────────────

  async _approveTokens() {
    for (const [symbol, addr] of Object.entries(TOKEN_ADDRESSES)) {
      if (!addr) continue;  // skip native
      try {
        const token = new ethers.Contract(addr, TOKEN_ABI, this.wallet);
        const allowance = await token.allowance(this.wallet.address, CONFIG.VAULT_CONTRACT);
        if (allowance < ethers.MaxUint256 / 2n) {
          logger.info(`Approving ${symbol} for vault…`);
          const tx = await token.approve(CONFIG.VAULT_CONTRACT, ethers.MaxUint256);
          await tx.wait();
          logger.info(`${symbol} approved ✓`);
        }
      } catch (err) {
        logger.warn(`Could not approve ${symbol}: ${err.message}`);
      }
    }
  }

  // ── Main Loop ──────────────────────────────────────────────────────────────

  async start() {
    this.isRunning = true;
    logger.info(`Starting merchant loop for pairs: ${CONFIG.PAIRS.join(", ")}`);
    logger.info(`Spread: ${CONFIG.SPREAD_PCT}% | Orders: $${CONFIG.MIN_ORDER_USD}-$${CONFIG.MAX_ORDER_USD}`);

    while (this.isRunning) {
      for (const pair of CONFIG.PAIRS) {
        try {
          await this._processPair(pair);
        } catch (err) {
          logger.error(`Error processing ${pair}: ${err.message}`);
        }
      }
      await this._sleep(CONFIG.POLL_MS);
    }
  }

  stop() {
    this.isRunning = false;
    logger.info("Merchant bot stopped");
  }

  // ── Process a single trading pair ─────────────────────────────────────────

  async _processPair(pair) {
    const symbol = pair.replace("/", "");
    const [base]  = pair.split("/");

    // 1. Get current market price
    const ticker = await this.exchange.fetchTicker(pair);
    const mid    = (ticker.bid + ticker.ask) / 2;
    if (!mid) return;

    // 2. Compute spread prices
    const spread  = CONFIG.SPREAD_PCT / 100;
    const buyAt   = mid * (1 - spread / 2);   // we buy from sellers
    const sellAt  = mid * (1 + spread / 2);   // we sell to buyers
    const spreadPerUnit = sellAt - buyAt;

    logger.info(`${pair} | Mid: ${mid.toFixed(4)} | Buy@: ${buyAt.toFixed(4)} | Sell@: ${sellAt.toFixed(4)} | Spread: $${spreadPerUnit.toFixed(4)}`);

    // 3. Check existing P2P orders on exchange
    const p2pOrders = await this._fetchP2POrders(pair, mid, buyAt, sellAt);
    if (!p2pOrders) return;

    // 4. Match profitable orders
    for (const match of p2pOrders.matches) {
      if (!this._checkInventoryLimits(base, match.amount)) continue;

      const profit = match.amount * spreadPerUnit;
      logger.info(`Matched ${pair}: amount=${match.amount.toFixed(4)} profit=$${profit.toFixed(4)}`);

      // 5. Execute on exchange
      const txRef = await this._executeTrade(pair, match);
      if (!txRef) continue;

      // 6. Deposit profit to vault
      await this._depositToVault(pair, base, profit, txRef);

      this.totalProfit += profit;
      this.tradeCount++;
    }

    // 7. Log session stats
    if (this.tradeCount % 10 === 0 && this.tradeCount > 0) {
      logger.info(`SESSION | Trades: ${this.tradeCount} | Total Profit: $${this.totalProfit.toFixed(2)}`);
    }
  }

  // ── Fetch simulated P2P order book ─────────────────────────────────────────

  async _fetchP2POrders(pair, mid, buyAt, sellAt) {
    try {
      const orderbook = await this.exchange.fetchOrderBook(pair, 20);
      const matches   = [];

      // Sellers willing to sell BELOW our buy price
      for (const [askPrice, askVol] of orderbook.asks) {
        if (askPrice <= buyAt) {
          const usdVal = askPrice * askVol;
          if (usdVal >= CONFIG.MIN_ORDER_USD && usdVal <= CONFIG.MAX_ORDER_USD) {
            matches.push({ side: "buy", price: askPrice, amount: askVol, usdVal });
          }
        }
      }

      // Buyers willing to buy ABOVE our sell price
      for (const [bidPrice, bidVol] of orderbook.bids) {
        if (bidPrice >= sellAt) {
          const usdVal = bidPrice * bidVol;
          if (usdVal >= CONFIG.MIN_ORDER_USD && usdVal <= CONFIG.MAX_ORDER_USD) {
            matches.push({ side: "sell", price: bidPrice, amount: bidVol, usdVal });
          }
        }
      }

      return { matches };
    } catch (err) {
      logger.warn(`Order book fetch failed for ${pair}: ${err.message}`);
      return null;
    }
  }

  // ── Execute trade on exchange ──────────────────────────────────────────────

  async _executeTrade(pair, match) {
    try {
      const order = await this.exchange.createOrder(
        pair,
        "limit",
        match.side,
        match.amount,
        match.price,
        { timeInForce: "GTC", postOnly: false }
      );
      logger.info(`Order placed: ${order.id} ${match.side} ${match.amount} @ ${match.price}`);

      // Update inventory
      const [base, quote] = pair.split("/");
      if (match.side === "buy") {
        this.inventory[base]  = (this.inventory[base]  || 0) + match.amount;
        this.inventory[quote] = (this.inventory[quote] || 0) - match.amount * match.price;
      } else {
        this.inventory[base]  = (this.inventory[base]  || 0) - match.amount;
        this.inventory[quote] = (this.inventory[quote] || 0) + match.amount * match.price;
      }

      return order.id;
    } catch (err) {
      logger.error(`Trade execution failed: ${err.message}`);
      return null;
    }
  }

  // ── Deposit profit to vault contract ──────────────────────────────────────

  async _depositToVault(pair, profitToken, profitAmount, tradeRef) {
    const tokenAddr = TOKEN_ADDRESSES[profitToken];
    const txHash    = ethers.keccak256(ethers.toUtf8Bytes(tradeRef + Date.now()));
    const spreadBps = Math.round(CONFIG.SPREAD_PCT * 100);

    try {
      let tx;
      if (!tokenAddr) {
        // Native asset profit
        const value = ethers.parseEther(profitAmount.toFixed(18));
        tx = await this.vault.depositNativeProfit(
          CONFIG.MERCHANT_ADDR, spreadBps,
          this.exchangeId, pair, txHash,
          { value }
        );
      } else {
        // ERC-20 profit
        const decimals = profitToken === "USDT" || profitToken === "USDC" ? 18 : 18;
        const amountWei = ethers.parseUnits(profitAmount.toFixed(decimals), decimals);
        tx = await this.vault.depositProfit(
          CONFIG.MERCHANT_ADDR, tokenAddr, amountWei,
          spreadBps, this.exchangeId, pair, txHash
        );
      }

      const receipt = await tx.wait();
      logger.info(`Vault deposit confirmed | Tx: ${receipt.hash} | Profit: ${profitAmount.toFixed(6)} ${profitToken}`);
      return receipt.hash;
    } catch (err) {
      logger.error(`Vault deposit failed: ${err.message}`);
      return null;
    }
  }

  // ── Risk checks ────────────────────────────────────────────────────────────

  _checkInventoryLimits(token, amount) {
    const current = this.inventory[token] || 0;
    if (Math.abs(current) > CONFIG.MAX_INVENTORY) {
      logger.warn(`Inventory limit reached for ${token}: ${current}`);
      return false;
    }
    return true;
  }

  // ── Utility ────────────────────────────────────────────────────────────────

  _sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  getStats() {
    return {
      exchange:    this.exchangeId,
      trades:      this.tradeCount,
      profit:      this.totalProfit,
      inventory:   this.inventory,
      isRunning:   this.isRunning,
    };
  }
}

// ─── Multi-Exchange Orchestrator ──────────────────────────────────────────────

class MultiExchangeOrchestrator {
  constructor() {
    this.bots = new Map();
  }

  async addExchange(exchangeId) {
    if (this.bots.has(exchangeId)) return;
    const bot = new AIMerchantBot(exchangeId);
    await bot.init();
    this.bots.set(exchangeId, bot);
    logger.info(`Exchange added: ${exchangeId}`);
  }

  async startAll() {
    const promises = [];
    for (const [id, bot] of this.bots) {
      logger.info(`Starting bot on ${id}…`);
      promises.push(bot.start());
    }
    await Promise.all(promises);
  }

  stopAll() {
    for (const bot of this.bots.values()) bot.stop();
  }

  getAggregateStats() {
    let totalTrades = 0, totalProfit = 0;
    const byExchange = {};
    for (const [id, bot] of this.bots) {
      const s = bot.getStats();
      totalTrades  += s.trades;
      totalProfit  += s.profit;
      byExchange[id] = s;
    }
    return { totalTrades, totalProfit, byExchange };
  }
}

// ─── Entry Point ──────────────────────────────────────────────────────────────

async function main() {
  const args        = process.argv.slice(2);
  const exchangeArg = args.find(a => a.startsWith("--exchange="))?.split("=")[1];
  const multiArg    = args.includes("--multi");

  if (multiArg) {
    // Run on multiple exchanges simultaneously
    const orchestrator = new MultiExchangeOrchestrator();
    const targets = ["binance", "okx", "bybit", "kucoin"];

    for (const ex of targets) {
      try {
        await orchestrator.addExchange(ex);
      } catch (err) {
        logger.warn(`Could not add ${ex}: ${err.message}`);
      }
    }

    process.on("SIGINT", () => {
      logger.info("Shutting down...");
      orchestrator.stopAll();
      const stats = orchestrator.getAggregateStats();
      logger.info(`Final stats: ${JSON.stringify(stats, null, 2)}`);
      process.exit(0);
    });

    await orchestrator.startAll();
  } else {
    // Single exchange mode
    const bot = new AIMerchantBot(exchangeArg || CONFIG.EXCHANGE_ID);
    await bot.init();

    process.on("SIGINT", () => {
      bot.stop();
      logger.info(`Final: ${JSON.stringify(bot.getStats(), null, 2)}`);
      process.exit(0);
    });

    await bot.start();
  }
}

main().catch(err => {
  logger.error(`Fatal error: ${err.message}`);
  process.exit(1);
});

module.exports = { AIMerchantBot, MultiExchangeOrchestrator };
