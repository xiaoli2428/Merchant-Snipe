// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";
import "@openzeppelin/contracts/security/Pausable.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

/**
 * @title P2PMerchantProfitVault
 * @notice On-chain profit vault for the AI P2P Merchant protocol.
 *         Collects spread profits from any exchange, stores them as
 *         crypto assets, and tracks per-address balances.
 *
 * Contract Address (BSC Mainnet — deploy to get real address):
 *   Deploy via: npx hardhat run scripts/deploy.js --network bsc
 *
 * Architecture:
 *   ┌─────────────────────────────────────────────┐
 *   │            AI Merchant Bot Layer             │
 *   │  (Binance / KuCoin / OKX / Bybit / etc.)    │
 *   └──────────────────┬──────────────────────────┘
 *                      │ depositProfit()
 *                      ▼
 *   ┌─────────────────────────────────────────────┐
 *   │         ProfitVault (this contract)          │
 *   │  - vaultBalances[token][address]             │
 *   │  - exchangeRegistry[]                        │
 *   │  - merchantRegistry[]                        │
 *   │  - AdminDashboard events                     │
 *   └─────────────────────────────────────────────┘
 */
contract ProfitVaultProtocol is Ownable, ReentrancyGuard, Pausable {
    using SafeERC20 for IERC20;

    // ─── Constants ────────────────────────────────────────────────────────────
    uint256 public constant PROTOCOL_FEE_BPS = 50;   // 0.5% protocol fee on profits
    uint256 public constant BPS_DENOMINATOR  = 10000;
    uint256 public constant MAX_MERCHANTS    = 500;

    // ─── Structs ──────────────────────────────────────────────────────────────

    struct Merchant {
        address addr;
        string  name;
        bool    isActive;
        uint256 totalProfitUSD;   // scaled by 1e6
        uint256 totalTrades;
        uint256 registeredAt;
        uint256 lastActivityAt;
        string  exchange;         // primary exchange identifier
    }

    struct Exchange {
        string  id;               // "binance", "kucoin", "okx", "bybit", etc.
        string  name;
        bool    isActive;
        uint256 totalVolumeUSD;
        uint256 totalTrades;
        address operatorAddress;
    }

    struct TradeRecord {
        uint256 id;
        address merchant;
        address token;
        uint256 amount;           // profit amount in token units
        uint256 spreadBps;        // spread in basis points
        string  exchangeId;
        string  pair;             // e.g. "USDT/USD", "BTC/USDT"
        uint256 timestamp;
        bytes32 txHash;           // off-chain trade reference
    }

    struct WithdrawalRequest {
        uint256 id;
        address merchant;
        address token;
        uint256 amount;
        uint256 requestedAt;
        bool    approved;
        bool    executed;
        bool    rejected;
    }

    // ─── State ────────────────────────────────────────────────────────────────

    // vault[token][merchant] => balance
    mapping(address => mapping(address => uint256)) public vaultBalance;

    // Protocol fee accumulator: feeReserve[token]
    mapping(address => uint256) public feeReserve;

    // Registered merchants
    mapping(address => Merchant) public merchants;
    address[] public merchantList;

    // Registered exchanges
    mapping(string => Exchange) public exchanges;
    string[] public exchangeIds;

    // Trade history
    TradeRecord[] public trades;
    mapping(address => uint256[]) public merchantTradeIds;

    // Withdrawal queue
    WithdrawalRequest[] public withdrawalQueue;
    mapping(address => uint256[]) public merchantWithdrawals;

    // Approved deposit operators (can call depositProfit)
    mapping(address => bool) public operators;

    // Supported tokens
    mapping(address => bool) public supportedTokens;
    address[] public tokenList;

    // Aggregate stats
    uint256 public totalProfitAllTime;  // in USD * 1e6
    uint256 public totalTradesAllTime;

    uint256 private _tradeCounter;
    uint256 private _withdrawalCounter;

    // ─── Events ───────────────────────────────────────────────────────────────

    event ProfitDeposited(
        address indexed merchant,
        address indexed token,
        uint256 amount,
        uint256 fee,
        string  exchangeId,
        string  pair,
        uint256 spreadBps,
        uint256 indexed tradeId
    );

    event ProfitWithdrawn(
        address indexed merchant,
        address indexed token,
        uint256 amount,
        uint256 withdrawalId
    );

    event MerchantRegistered(address indexed merchant, string name, string exchange);
    event MerchantDeactivated(address indexed merchant);
    event ExchangeRegistered(string id, string name, address operator);
    event TokenAdded(address indexed token, string symbol);
    event OperatorSet(address indexed operator, bool status);
    event WithdrawalRequested(uint256 indexed id, address indexed merchant, address token, uint256 amount);
    event WithdrawalApproved(uint256 indexed id);
    event WithdrawalRejected(uint256 indexed id, string reason);
    event FeeWithdrawn(address indexed token, uint256 amount, address to);
    event EmergencyPause(address by);

    // ─── Modifiers ────────────────────────────────────────────────────────────

    modifier onlyOperator() {
        require(operators[msg.sender] || msg.sender == owner(), "Not an operator");
        _;
    }

    modifier onlyRegisteredMerchant() {
        require(merchants[msg.sender].addr != address(0), "Not a registered merchant");
        require(merchants[msg.sender].isActive, "Merchant inactive");
        _;
    }

    modifier onlySupportedToken(address token) {
        require(supportedTokens[token], "Token not supported");
        _;
    }

    // ─── Constructor ──────────────────────────────────────────────────────────

    constructor() Ownable(msg.sender) {
        // Register default exchanges
        _registerExchange("binance",  "Binance",   msg.sender);
        _registerExchange("kucoin",   "KuCoin",    msg.sender);
        _registerExchange("okx",      "OKX",       msg.sender);
        _registerExchange("bybit",    "Bybit",     msg.sender);
        _registerExchange("huobi",    "HTX/Huobi", msg.sender);
        _registerExchange("gate",     "Gate.io",   msg.sender);
        _registerExchange("mexc",     "MEXC",      msg.sender);
        _registerExchange("bitget",   "Bitget",    msg.sender);
        _registerExchange("kraken",   "Kraken",    msg.sender);
        _registerExchange("coinbase", "Coinbase",  msg.sender);

        operators[msg.sender] = true;
    }

    // ─── Core: Deposit Profit ─────────────────────────────────────────────────

    /**
     * @notice Called by the AI merchant bot after each profitable trade.
     *         Deposits spread profit into the vault, deducts protocol fee.
     * @param merchant   Merchant wallet address
     * @param token      ERC-20 token address of the profit asset
     * @param amount     Raw profit amount (in token units)
     * @param spreadBps  Spread used (in basis points, e.g. 80 = 0.8%)
     * @param exchangeId Exchange identifier string
     * @param pair       Trading pair string e.g. "USDT/USD"
     * @param txHash     Off-chain trade reference hash
     */
    function depositProfit(
        address merchant,
        address token,
        uint256 amount,
        uint256 spreadBps,
        string  calldata exchangeId,
        string  calldata pair,
        bytes32 txHash
    )
        external
        nonReentrant
        whenNotPaused
        onlyOperator
        onlySupportedToken(token)
    {
        require(merchant != address(0), "Invalid merchant");
        require(amount > 0, "Amount must be > 0");
        require(merchants[merchant].isActive, "Merchant not active");
        require(exchanges[exchangeId].isActive, "Exchange not active");

        // Pull tokens from sender
        IERC20(token).safeTransferFrom(msg.sender, address(this), amount);

        // Calculate and deduct protocol fee
        uint256 fee    = (amount * PROTOCOL_FEE_BPS) / BPS_DENOMINATOR;
        uint256 net    = amount - fee;
        feeReserve[token] += fee;

        // Credit merchant vault
        vaultBalance[token][merchant] += net;

        // Record trade
        uint256 tid = ++_tradeCounter;
        trades.push(TradeRecord({
            id:         tid,
            merchant:   merchant,
            token:      token,
            amount:     net,
            spreadBps:  spreadBps,
            exchangeId: exchangeId,
            pair:       pair,
            timestamp:  block.timestamp,
            txHash:     txHash
        }));
        merchantTradeIds[merchant].push(tid - 1);

        // Update merchant stats
        merchants[merchant].totalTrades++;
        merchants[merchant].lastActivityAt = block.timestamp;

        // Update exchange stats
        exchanges[exchangeId].totalTrades++;

        totalTradesAllTime++;

        emit ProfitDeposited(merchant, token, net, fee, exchangeId, pair, spreadBps, tid);
    }

    /**
     * @notice Deposit native ETH/BNB profit (for chains where native asset is used)
     */
    function depositNativeProfit(
        address merchant,
        uint256 spreadBps,
        string  calldata exchangeId,
        string  calldata pair,
        bytes32 txHash
    )
        external
        payable
        nonReentrant
        whenNotPaused
        onlyOperator
    {
        require(msg.value > 0, "No value sent");
        require(merchants[merchant].isActive, "Merchant not active");

        uint256 fee = (msg.value * PROTOCOL_FEE_BPS) / BPS_DENOMINATOR;
        uint256 net = msg.value - fee;

        // address(0) = native asset
        vaultBalance[address(0)][merchant] += net;
        feeReserve[address(0)] += fee;

        uint256 tid = ++_tradeCounter;
        trades.push(TradeRecord({
            id:         tid,
            merchant:   merchant,
            token:      address(0),
            amount:     net,
            spreadBps:  spreadBps,
            exchangeId: exchangeId,
            pair:       pair,
            timestamp:  block.timestamp,
            txHash:     txHash
        }));
        merchantTradeIds[merchant].push(tid - 1);
        merchants[merchant].totalTrades++;
        totalTradesAllTime++;

        emit ProfitDeposited(merchant, address(0), net, fee, exchangeId, pair, spreadBps, tid);
    }

    // ─── Merchant: Withdraw Profits ───────────────────────────────────────────

    /**
     * @notice Merchant requests withdrawal of accumulated profits.
     *         Requires admin approval (2-step for security).
     */
    function requestWithdrawal(address token, uint256 amount)
        external
        nonReentrant
        onlyRegisteredMerchant
    {
        require(amount > 0, "Amount must be > 0");
        require(vaultBalance[token][msg.sender] >= amount, "Insufficient vault balance");

        // Lock the balance
        vaultBalance[token][msg.sender] -= amount;

        uint256 wid = _withdrawalCounter++;
        withdrawalQueue.push(WithdrawalRequest({
            id:          wid,
            merchant:    msg.sender,
            token:       token,
            amount:      amount,
            requestedAt: block.timestamp,
            approved:    false,
            executed:    false,
            rejected:    false
        }));
        merchantWithdrawals[msg.sender].push(wid);

        emit WithdrawalRequested(wid, msg.sender, token, amount);
    }

    /**
     * @notice Admin approves and executes a pending withdrawal.
     */
    function approveWithdrawal(uint256 withdrawalId)
        external
        nonReentrant
        onlyOwner
    {
        WithdrawalRequest storage req = withdrawalQueue[withdrawalId];
        require(!req.approved && !req.rejected, "Already processed");

        req.approved = true;
        req.executed = true;

        if (req.token == address(0)) {
            (bool ok,) = payable(req.merchant).call{value: req.amount}("");
            require(ok, "Native transfer failed");
        } else {
            IERC20(req.token).safeTransfer(req.merchant, req.amount);
        }

        emit WithdrawalApproved(withdrawalId);
        emit ProfitWithdrawn(req.merchant, req.token, req.amount, withdrawalId);
    }

    /**
     * @notice Admin rejects a withdrawal request, returning balance to vault.
     */
    function rejectWithdrawal(uint256 withdrawalId, string calldata reason)
        external
        onlyOwner
    {
        WithdrawalRequest storage req = withdrawalQueue[withdrawalId];
        require(!req.approved && !req.rejected, "Already processed");

        req.rejected = true;
        // Return locked balance to merchant
        vaultBalance[req.token][req.merchant] += req.amount;

        emit WithdrawalRejected(withdrawalId, reason);
    }

    // ─── Admin: Merchant Management ───────────────────────────────────────────

    function registerMerchant(
        address addr,
        string calldata name,
        string calldata exchange
    ) external onlyOwner {
        require(addr != address(0), "Invalid address");
        require(merchants[addr].addr == address(0), "Already registered");
        require(merchantList.length < MAX_MERCHANTS, "Merchant limit reached");

        merchants[addr] = Merchant({
            addr:            addr,
            name:            name,
            isActive:        true,
            totalProfitUSD:  0,
            totalTrades:     0,
            registeredAt:    block.timestamp,
            lastActivityAt:  block.timestamp,
            exchange:        exchange
        });
        merchantList.push(addr);

        emit MerchantRegistered(addr, name, exchange);
    }

    function deactivateMerchant(address addr) external onlyOwner {
        merchants[addr].isActive = false;
        emit MerchantDeactivated(addr);
    }

    function reactivateMerchant(address addr) external onlyOwner {
        merchants[addr].isActive = true;
    }

    // ─── Admin: Exchange Management ───────────────────────────────────────────

    function addExchange(
        string calldata id,
        string calldata name,
        address operator
    ) external onlyOwner {
        _registerExchange(id, name, operator);
    }

    function _registerExchange(
        string memory id,
        string memory name,
        address operator
    ) internal {
        exchanges[id] = Exchange({
            id:              id,
            name:            name,
            isActive:        true,
            totalVolumeUSD:  0,
            totalTrades:     0,
            operatorAddress: operator
        });
        exchangeIds.push(id);
        emit ExchangeRegistered(id, name, operator);
    }

    function setExchangeActive(string calldata id, bool active) external onlyOwner {
        exchanges[id].isActive = active;
    }

    // ─── Admin: Token & Operator Management ──────────────────────────────────

    function addSupportedToken(address token, string calldata symbol) external onlyOwner {
        require(!supportedTokens[token], "Already added");
        supportedTokens[token] = true;
        tokenList.push(token);
        emit TokenAdded(token, symbol);
    }

    function setOperator(address op, bool status) external onlyOwner {
        operators[op] = status;
        emit OperatorSet(op, status);
    }

    // ─── Admin: Fee Withdrawal ────────────────────────────────────────────────

    function withdrawFees(address token, address to) external onlyOwner nonReentrant {
        uint256 amount = feeReserve[token];
        require(amount > 0, "No fees to withdraw");
        feeReserve[token] = 0;

        if (token == address(0)) {
            (bool ok,) = payable(to).call{value: amount}("");
            require(ok, "Transfer failed");
        } else {
            IERC20(token).safeTransfer(to, amount);
        }

        emit FeeWithdrawn(token, amount, to);
    }

    // ─── Emergency ────────────────────────────────────────────────────────────

    function emergencyPause() external onlyOwner {
        _pause();
        emit EmergencyPause(msg.sender);
    }

    function unpause() external onlyOwner {
        _unpause();
    }

    // ─── View Functions ───────────────────────────────────────────────────────

    function getMerchantBalance(address merchant, address token)
        external view returns (uint256) {
        return vaultBalance[token][merchant];
    }

    function getMerchantCount() external view returns (uint256) {
        return merchantList.length;
    }

    function getTradeCount() external view returns (uint256) {
        return trades.length;
    }

    function getMerchantTrades(address merchant)
        external view returns (uint256[] memory) {
        return merchantTradeIds[merchant];
    }

    function getExchangeCount() external view returns (uint256) {
        return exchangeIds.length;
    }

    function getTokenCount() external view returns (uint256) {
        return tokenList.length;
    }

    function getPendingWithdrawals() external view returns (uint256 count) {
        for (uint i = 0; i < withdrawalQueue.length; i++) {
            if (!withdrawalQueue[i].approved && !withdrawalQueue[i].rejected) count++;
        }
    }

    receive() external payable {}
}
