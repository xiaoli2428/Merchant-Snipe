import { useState, useEffect, useRef, useCallback } from "react";

const CONTRACT_ADDRESS = "0x7F3A9c2B4E1D8f56aC90bE3d12F47aE6C8b5D921";

const TOKENS = [
  { symbol: "USDT", address: "0x55d398326f99059fF775485246999027B3197955", decimals: 18, color: "#26A17B" },
  { symbol: "USDC", address: "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d", decimals: 18, color: "#2775CA" },
  { symbol: "BTC",  address: "0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c", decimals: 18, color: "#F7931A" },
  { symbol: "ETH",  address: "0x2170Ed0880ac9A755fd29B2688956BD959F933F8", decimals: 18, color: "#627EEA" },
  { symbol: "BNB",  address: "0x0000000000000000000000000000000000000000", decimals: 18, color: "#F3BA2F" },
  { symbol: "XRP",  address: "0x1D2F0da169ceB9fC7B3144628dB156f3F6c60dBE", decimals: 18, color: "#0085C0" },
  { symbol: "SOL",  address: "0x570A5D26f7765Ecb712C0924E4De545B89fD43dF", decimals: 18, color: "#9945FF" },
  { symbol: "ADA",  address: "0x3EE2200Efb3400fAbB9AacF31297cBdD1d435D47", decimals: 18, color: "#0033AD" },
];

const EXCHANGES = [
  { id: "binance",  name: "Binance",   region: "Global", logo: "🟡", active: true,  vol: 4820000, trades: 1842 },
  { id: "okx",      name: "OKX",       region: "Global", logo: "⬛", active: true,  vol: 2110000, trades: 941  },
  { id: "bybit",    name: "Bybit",     region: "Global", logo: "🟠", active: true,  vol: 1640000, trades: 723  },
  { id: "kucoin",   name: "KuCoin",    region: "Global", logo: "🟢", active: true,  vol: 980000,  trades: 412  },
  { id: "huobi",    name: "HTX/Huobi", region: "Asia",   logo: "🔵", active: true,  vol: 760000,  trades: 318  },
  { id: "gate",     name: "Gate.io",   region: "Global", logo: "🔷", active: true,  vol: 540000,  trades: 229  },
  { id: "mexc",     name: "MEXC",      region: "Global", logo: "🟣", active: false, vol: 320000,  trades: 138  },
  { id: "bitget",   name: "Bitget",    region: "Global", logo: "🔶", active: true,  vol: 490000,  trades: 197  },
  { id: "kraken",   name: "Kraken",    region: "US/EU",  logo: "🦑", active: true,  vol: 280000,  trades: 112  },
  { id: "coinbase", name: "Coinbase",  region: "US",     logo: "🔵", active: false, vol: 190000,  trades: 77   },
  { id: "bitfinex", name: "Bitfinex",  region: "EU",     logo: "⬜", active: true,  vol: 145000,  trades: 61   },
  { id: "phemex",   name: "Phemex",    region: "Asia",   logo: "🔴", active: false, vol: 98000,   trades: 43   },
];

const INIT_MERCHANTS = [
  { addr: "0x1aB2c3D4e5F6a7B8c9D0e1F2a3B4c5D6e7F8a9B0", name: "AlphaBot-01",   exchange: "binance", active: true,  profit: 142850, trades: 4821 },
  { addr: "0x2bC3D4e5F6a7B8c9D0e1F2a3B4c5D6e7F8a9B0c1", name: "BetaMerchant",  exchange: "okx",     active: true,  profit: 98340,  trades: 3102 },
  { addr: "0x3cD4e5F6a7B8c9D0e1F2a3B4c5D6e7F8a9B0c1D2", name: "GammaGrid",     exchange: "bybit",   active: true,  profit: 67210,  trades: 2481 },
  { addr: "0x4dE5f6A7b8C9d0E1f2A3b4C5d6E7f8A9b0C1d2E3", name: "DeltaDesk",     exchange: "kucoin",  active: false, profit: 41720,  trades: 1390 },
  { addr: "0x5eF6a7B8c9D0e1F2a3B4c5D6e7F8a9B0c1D2e3F4", name: "EpsilonArb",    exchange: "huobi",   active: true,  profit: 29880,  trades: 983  },
];

function rand(min, max) { return Math.random()*(max-min)+min; }
function shortAddr(a) { return a?`${a.slice(0,6)}…${a.slice(-4)}`:"—"; }
function fmtUSD(n) {
  if(n>=1000000) return `$${(n/1000000).toFixed(2)}M`;
  if(n>=1000)    return `$${(n/1000).toFixed(2)}K`;
  return `$${Number(n).toFixed(2)}`;
}
function fmtN(n,d=4){ return Number(n).toLocaleString("en-US",{minimumFractionDigits:d,maximumFractionDigits:d}); }
function timeAgo(ts){ const s=Math.floor((Date.now()-ts)/1000); if(s<60)return`${s}s ago`; if(s<3600)return`${Math.floor(s/60)}m ago`; return`${Math.floor(s/3600)}h ago`; }

let tradeId=5000, wdId=200;
function seedTrades(n=25){
  return Array.from({length:n},()=>{
    const tok=TOKENS[Math.floor(rand(0,5))];
    const ex=EXCHANGES[Math.floor(rand(0,8))];
    const m=INIT_MERCHANTS[Math.floor(rand(0,5))];
    const sp=rand(0.3,1.5); const amt=rand(20,900);
    return {id:++tradeId,tradeRef:`0x${Array.from({length:14},()=>"0123456789abcdef"[Math.floor(Math.random()*16)]).join("")}`,merchant:m.addr,mName:m.name,token:tok.symbol,tokenColor:tok.color,tokenAddr:tok.address,amount:amt,spreadPct:sp,exchange:ex.id,exName:ex.name,pair:`${tok.symbol}/USDT`,ts:Date.now()-Math.floor(rand(60000,86400000)),profit:amt*(sp/100),fee:amt*(sp/100)*0.005};
  }).sort((a,b)=>b.ts-a.ts);
}
function seedWd(){
  return [
    {id:++wdId,merchant:INIT_MERCHANTS[0].addr,mName:INIT_MERCHANTS[0].name,token:"USDT",amount:12000,status:"pending",ts:Date.now()-1800000},
    {id:++wdId,merchant:INIT_MERCHANTS[2].addr,mName:INIT_MERCHANTS[2].name,token:"BTC",amount:0.28,status:"approved",ts:Date.now()-7200000},
    {id:++wdId,merchant:INIT_MERCHANTS[1].addr,mName:INIT_MERCHANTS[1].name,token:"ETH",amount:2.14,status:"pending",ts:Date.now()-3600000},
    {id:++wdId,merchant:INIT_MERCHANTS[4].addr,mName:INIT_MERCHANTS[4].name,token:"USDT",amount:5400,status:"rejected",ts:Date.now()-14400000},
  ];
}

const C={bg:"#070B10",panel:"#0E1420",border:"#1C2536",text:"#D1D9E6",muted:"#5A6478",accent:"#00E5FF",green:"#00D68F",red:"#FF4C6A",gold:"#FFD166",purple:"#A78BFA",orange:"#FF8C00"};

function Badge({children,color}){ return <span style={{background:`${color}22`,color,padding:"2px 8px",borderRadius:4,fontSize:11,fontFamily:"JetBrains Mono,monospace",fontWeight:600}}>{children}</span>; }

function Toast({toast}){
  if(!toast) return null;
  const col=toast.type==="error"?C.red:toast.type==="warn"?C.gold:C.green;
  const bg=toast.type==="error"?"#2A0A0E":toast.type==="warn"?"#1A1500":"#0A1E14";
  return <div style={{position:"fixed",top:20,right:20,zIndex:999,background:bg,border:`1px solid ${col}`,color:col,borderRadius:8,padding:"10px 18px",fontSize:12,fontFamily:"JetBrains Mono,monospace",maxWidth:340,boxShadow:"0 4px 24px rgba(0,0,0,0.5)"}}>{toast.type==="error"?"✕ ":toast.type==="warn"?"⚠ ":"✓ "}{toast.msg}</div>;
}

const TH=({children})=><th style={{padding:"6px 12px",color:C.muted,fontSize:11,fontWeight:500,textAlign:"left",borderBottom:`1px solid ${C.border}`,fontFamily:"JetBrains Mono,monospace",whiteSpace:"nowrap"}}>{children}</th>;
const TD=({children,color,bold})=><td style={{padding:"8px 12px",borderBottom:`1px solid #0E1420`,fontFamily:"JetBrains Mono,monospace",fontSize:12,color:color||C.text,fontWeight:bold?"700":"400"}}>{children}</td>;

export default function App(){
  const [page,setPage]=useState("overview");
  const [merchants,setMerchants]=useState(INIT_MERCHANTS);
  const [trades,setTrades]=useState(()=>seedTrades(25));
  const [withdrawals,setWithdrawals]=useState(()=>seedWd());
  const [exchanges,setExchanges]=useState(EXCHANGES);
  const [tokenList,setTokenList]=useState(TOKENS.slice(0,6));
  const [live,setLive]=useState(false);
  const [totalProfit,setTotalProfit]=useState(382450.84);
  const [totalFees,setTotalFees]=useState(1912.25);
  const [newM,setNewM]=useState({addr:"",name:"",exchange:"binance"});
  const [newT,setNewT]=useState({symbol:"",address:"",decimals:"18"});
  const [toast,setToast]=useState(null);
  const [exFilter,setExFilter]=useState("all");
  const timerRef=useRef(null);

  const showToast=useCallback((msg,type="success")=>{setToast({msg,type});setTimeout(()=>setToast(null),3000);},[]);

  useEffect(()=>{
    if(!live) return;
    timerRef.current=setInterval(()=>{
      const tok=TOKENS[Math.floor(rand(0,8))];
      const ex=exchanges.find(e=>e.active)||exchanges[0];
      const m=merchants.find(m=>m.active)||merchants[0];
      const sp=rand(0.4,1.2); const amt=rand(50,1200);
      const profit=amt*(sp/100); const fee=profit*0.005; const net=profit-fee;
      setTrades(p=>[{id:++tradeId,tradeRef:`0x${Array.from({length:14},()=>"0123456789abcdef"[Math.floor(Math.random()*16)]).join("")}`,merchant:m.addr,mName:m.name,token:tok.symbol,tokenColor:tok.color,tokenAddr:tok.address,amount:amt,spreadPct:sp,exchange:ex.id,exName:ex.name,pair:`${tok.symbol}/USDT`,ts:Date.now(),profit:net,fee},...p].slice(0,100));
      setTotalProfit(p=>p+net); setTotalFees(f=>f+fee);
      setMerchants(p=>p.map(mm=>mm.addr===m.addr?{...mm,profit:mm.profit+net,trades:mm.trades+1}:mm));
    },rand(1500,3500));
    return()=>clearInterval(timerRef.current);
  },[live,exchanges,merchants]);

  const activeMerchants=merchants.filter(m=>m.active).length;
  const activeExchanges=exchanges.filter(e=>e.active).length;
  const pendingWd=withdrawals.filter(w=>w.status==="pending").length;

  const input={background:"#070B10",border:`1px solid ${C.border}`,borderRadius:6,color:C.text,padding:"7px 11px",fontSize:12,fontFamily:"JetBrains Mono,monospace",outline:"none"};
  const btn=(bg,col="#000")=>({background:bg,color:col,border:"none",borderRadius:6,padding:"7px 16px",cursor:"pointer",fontWeight:600,fontSize:12});
  const card={background:C.panel,border:`1px solid ${C.border}`,borderRadius:10,padding:18};
  const H2={fontFamily:"JetBrains Mono,monospace",fontSize:11,color:C.muted,letterSpacing:"0.1em",marginBottom:14,textTransform:"uppercase"};
  const nav=(active)=>({display:"flex",alignItems:"center",gap:10,padding:"9px 20px",cursor:"pointer",background:active?"#162030":"transparent",borderLeft:active?`3px solid ${C.accent}`:"3px solid transparent",color:active?C.accent:C.muted,fontWeight:active?600:400,fontSize:13,border:"none",width:"100%",textAlign:"left"});

  const NAV=[
    {id:"overview",icon:"◉",label:"Overview"},
    {id:"merchants",icon:"⬡",label:"Merchants"},
    {id:"trades",icon:"⚡",label:"Trade History"},
    {id:"vault",icon:"◈",label:"Profit Vault"},
    {id:"withdrawals",icon:"↑",label:"Withdrawals"},
    {id:"exchanges",icon:"⇄",label:"Exchanges"},
    {id:"tokens",icon:"◎",label:"Tokens"},
    {id:"contract",icon:"⬕",label:"Contract"},
  ];

  return (
    <div style={{background:C.bg,minHeight:"100vh",color:C.text,fontFamily:"Inter,sans-serif",fontSize:13,display:"flex"}}>
      <Toast toast={toast}/>

      {/* Sidebar */}
      <div style={{width:220,background:C.panel,borderRight:`1px solid ${C.border}`,display:"flex",flexDirection:"column",padding:"0 0 16px 0",position:"fixed",top:0,left:0,bottom:0,zIndex:10}}>
        <div style={{padding:"18px 20px 14px",borderBottom:`1px solid ${C.border}`,marginBottom:10}}>
          <div style={{fontFamily:"JetBrains Mono,monospace",fontWeight:800,fontSize:15,color:C.accent,letterSpacing:"0.06em"}}>P2P·VAULT</div>
          <div style={{fontSize:10,color:C.muted,marginTop:2,fontFamily:"JetBrains Mono,monospace"}}>Admin Dashboard v2.0</div>
          <div style={{marginTop:8,display:"flex",alignItems:"center",gap:6}}>
            <div style={{width:6,height:6,borderRadius:"50%",background:live?C.green:C.muted,boxShadow:live?`0 0 8px ${C.green}`:"none"}}/>
            <span style={{fontSize:10,color:C.muted,fontFamily:"JetBrains Mono,monospace"}}>{live?"LIVE":"PAUSED"}</span>
          </div>
        </div>
        {NAV.map(n=>(
          <button key={n.id} style={nav(page===n.id)} onClick={()=>setPage(n.id)}>
            <span style={{fontSize:14}}>{n.icon}</span>{n.label}
            {n.id==="withdrawals"&&pendingWd>0&&<span style={{marginLeft:"auto",background:C.red,color:"#fff",borderRadius:10,padding:"1px 6px",fontSize:10,fontWeight:700}}>{pendingWd}</span>}
          </button>
        ))}
        <div style={{marginTop:"auto",padding:"0 16px",display:"flex",flexDirection:"column",gap:8}}>
          <button style={{...btn(live?"#1A1A2E":"#0A2E1A",live?C.red:C.green),width:"100%",border:`1px solid ${live?C.red:C.green}`}} onClick={()=>setLive(v=>!v)}>
            {live?"⏸ Pause Live":"▶ Start Live"}
          </button>
          <div style={{padding:"8px 10px",background:"#070B10",borderRadius:6,border:`1px solid ${C.border}`}}>
            <div style={{fontSize:10,color:C.muted,marginBottom:2}}>CONTRACT</div>
            <div style={{fontFamily:"JetBrains Mono,monospace",fontSize:10,color:C.accent,wordBreak:"break-all"}}>{shortAddr(CONTRACT_ADDRESS)}</div>
            <div style={{fontSize:9,color:C.muted}}>BSC Mainnet · Chain 56</div>
          </div>
        </div>
      </div>

      {/* Main */}
      <div style={{marginLeft:220,flex:1,padding:24,minHeight:"100vh"}}>

        {/* OVERVIEW */}
        {page==="overview"&&(
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div>
                <div style={{fontSize:20,fontWeight:700}}>Protocol Overview</div>
                <div style={{color:C.muted,fontSize:12,marginTop:2,fontFamily:"JetBrains Mono,monospace"}}>{CONTRACT_ADDRESS}</div>
              </div>
              <div style={{fontFamily:"JetBrains Mono,monospace",fontSize:11,color:C.muted}}>BNB Smart Chain · {new Date().toLocaleTimeString()}</div>
            </div>
            <div style={{display:"flex",gap:14,flexWrap:"wrap"}}>
              {[
                {label:"TOTAL PROFIT VAULTED",val:fmtUSD(totalProfit),color:C.gold},
                {label:"PROTOCOL FEES",val:fmtUSD(totalFees),color:C.accent},
                {label:"TOTAL TRADES",val:trades.length.toLocaleString(),color:C.green},
                {label:"ACTIVE MERCHANTS",val:activeMerchants,color:C.purple},
                {label:"ACTIVE EXCHANGES",val:activeExchanges,color:C.orange},
                {label:"PENDING WITHDRAWALS",val:pendingWd,color:pendingWd>0?C.red:C.muted},
              ].map(s=>(
                <div key={s.label} style={{background:C.panel,border:`1px solid ${s.color}22`,borderRadius:10,padding:"16px 20px",flex:"1 1 150px"}}>
                  <div style={{fontSize:10,color:C.muted,marginBottom:6,fontFamily:"JetBrains Mono,monospace",letterSpacing:"0.08em"}}>{s.label}</div>
                  <div style={{fontFamily:"JetBrains Mono,monospace",fontSize:24,fontWeight:800,color:s.color}}>{s.val}</div>
                </div>
              ))}
            </div>
            <div style={{display:"flex",gap:14,flexWrap:"wrap"}}>
              <div style={{...card,flex:2}}>
                <div style={H2}>Exchange Activity</div>
                <table style={{width:"100%",borderCollapse:"collapse"}}>
                  <thead><tr><TH>Exchange</TH><TH>Region</TH><TH>Trades</TH><TH>Volume</TH></tr></thead>
                  <tbody>{exchanges.filter(e=>e.active).map(ex=>(
                    <tr key={ex.id}><TD>{ex.logo} {ex.name}</TD><TD color={C.muted}>{ex.region}</TD><TD>{ex.trades.toLocaleString()}</TD><TD color={C.gold}>{fmtUSD(ex.vol)}</TD></tr>
                  ))}</tbody>
                </table>
              </div>
              <div style={{...card,flex:3}}>
                <div style={H2}>Live Trades</div>
                <table style={{width:"100%",borderCollapse:"collapse"}}>
                  <thead><tr><TH>Time</TH><TH>Merchant</TH><TH>Pair</TH><TH>Exchange</TH><TH>Spread</TH><TH>Profit</TH></tr></thead>
                  <tbody>{trades.slice(0,9).map(t=>(
                    <tr key={t.id}><TD color={C.muted}>{timeAgo(t.ts)}</TD><TD color={C.accent}>{t.mName}</TD><TD>{t.pair}</TD><TD color={C.muted}>{t.exName}</TD><TD color={C.purple}>{t.spreadPct.toFixed(2)}%</TD><TD color={C.gold} bold>+${fmtN(t.profit,4)}</TD></tr>
                  ))}</tbody>
                </table>
              </div>
            </div>
            <div style={card}>
              <div style={H2}>Top Merchants by Profit</div>
              <div style={{display:"flex",gap:12,flexWrap:"wrap"}}>
                {[...merchants].sort((a,b)=>b.profit-a.profit).map((m,i)=>(
                  <div key={m.addr} style={{flex:"1 1 180px",padding:"12px 14px",background:"#070B10",borderRadius:8,border:`1px solid ${C.border}`}}>
                    <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:6}}>
                      <span style={{fontFamily:"JetBrains Mono,monospace",color:i===0?C.gold:C.muted,fontWeight:700}}>#{i+1}</span>
                      <span style={{fontWeight:600,color:m.active?C.text:C.muted}}>{m.name}</span>
                      {!m.active&&<Badge color={C.red}>OFF</Badge>}
                    </div>
                    <div style={{fontFamily:"JetBrains Mono,monospace",fontSize:18,fontWeight:800,color:C.gold}}>{fmtUSD(m.profit)}</div>
                    <div style={{fontSize:11,color:C.muted,marginTop:4}}>{m.trades.toLocaleString()} trades · {shortAddr(m.addr)}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* MERCHANTS */}
        {page==="merchants"&&(
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            <div style={{fontSize:18,fontWeight:700}}>Merchant Registry</div>
            <div style={{...card,border:`1px solid ${C.accent}22`}}>
              <div style={H2}>Register New Merchant → Contract</div>
              <div style={{display:"flex",gap:10,flexWrap:"wrap"}}>
                <input style={{...input,flex:"2 1 240px"}} placeholder="Wallet address (0x…)" value={newM.addr} onChange={e=>setNewM(p=>({...p,addr:e.target.value}))}/>
                <input style={{...input,flex:"1 1 160px"}} placeholder="Merchant name" value={newM.name} onChange={e=>setNewM(p=>({...p,name:e.target.value}))}/>
                <select style={{...input,flex:"1 1 140px"}} value={newM.exchange} onChange={e=>setNewM(p=>({...p,exchange:e.target.value}))}>
                  {exchanges.map(ex=><option key={ex.id} value={ex.id}>{ex.name}</option>)}
                </select>
                <button style={btn(C.accent)} onClick={()=>{
                  if(!newM.addr||!newM.name)return showToast("Fill all fields","error");
                  setMerchants(p=>[...p,{addr:newM.addr,name:newM.name,exchange:newM.exchange,active:true,profit:0,trades:0}]);
                  setNewM({addr:"",name:"",exchange:"binance"});
                  showToast(`Merchant registered on-chain`);
                }}>Register</button>
              </div>
            </div>
            <div style={card}>
              <table style={{width:"100%",borderCollapse:"collapse"}}>
                <thead><tr><TH>Address</TH><TH>Name</TH><TH>Exchange</TH><TH>Status</TH><TH>Profit</TH><TH>Trades</TH><TH>Actions</TH></tr></thead>
                <tbody>{merchants.map(m=>(
                  <tr key={m.addr}>
                    <TD color={C.accent}>{shortAddr(m.addr)}</TD><TD>{m.name}</TD><TD color={C.muted}>{m.exchange}</TD>
                    <TD><Badge color={m.active?C.green:C.red}>{m.active?"ACTIVE":"INACTIVE"}</Badge></TD>
                    <TD color={C.gold} bold>{fmtUSD(m.profit)}</TD><TD>{m.trades.toLocaleString()}</TD>
                    <TD><div style={{display:"flex",gap:6}}>
                      {m.active
                        ?<button style={btn("#1A0A10",C.red)} onClick={()=>{setMerchants(p=>p.map(mm=>mm.addr===m.addr?{...mm,active:false}:mm));showToast("Deactivated","warn");}}>Deactivate</button>
                        :<button style={btn("#0A1A10",C.green)} onClick={()=>{setMerchants(p=>p.map(mm=>mm.addr===m.addr?{...mm,active:true}:mm));showToast("Activated");}}>Activate</button>}
                    </div></TD>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        )}

        {/* TRADES */}
        {page==="trades"&&(
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div style={{fontSize:18,fontWeight:700}}>Trade History ({trades.length})</div>
              <select style={{...input,width:"auto"}} value={exFilter} onChange={e=>setExFilter(e.target.value)}>
                <option value="all">All Exchanges</option>
                {exchanges.map(ex=><option key={ex.id} value={ex.id}>{ex.name}</option>)}
              </select>
            </div>
            <div style={card}>
              <div style={{maxHeight:520,overflowY:"auto"}}>
                <table style={{width:"100%",borderCollapse:"collapse"}}>
                  <thead style={{position:"sticky",top:0,background:C.panel}}><tr><TH>Ref</TH><TH>Merchant</TH><TH>Token</TH><TH>Pair</TH><TH>Exchange</TH><TH>Spread</TH><TH>Profit</TH><TH>Fee</TH><TH>Time</TH></tr></thead>
                  <tbody>{trades.filter(t=>exFilter==="all"||t.exchange===exFilter).map(t=>(
                    <tr key={t.id}>
                      <TD color={C.muted}>{t.tradeRef.slice(0,12)}…</TD>
                      <TD color={C.accent}>{t.mName}</TD>
                      <TD color={t.tokenColor||C.text}>{t.token}</TD>
                      <TD>{t.pair}</TD>
                      <TD color={C.muted}>{t.exName}</TD>
                      <TD color={C.purple}>{t.spreadPct.toFixed(2)}%</TD>
                      <TD color={C.gold} bold>+${fmtN(t.profit,4)}</TD>
                      <TD color={C.muted}>${fmtN(t.fee,4)}</TD>
                      <TD color={C.muted}>{timeAgo(t.ts)}</TD>
                    </tr>
                  ))}</tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* VAULT */}
        {page==="vault"&&(
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            <div style={{fontSize:18,fontWeight:700}}>Profit Vault Protocol</div>
            <div style={{...card,borderColor:`${C.gold}33`}}>
              <div style={H2}>Vault Contract Address · BSC Mainnet</div>
              <div style={{display:"flex",alignItems:"center",gap:12,background:"#070B10",borderRadius:8,padding:"14px 16px",border:`1px solid ${C.gold}33`}}>
                <div style={{fontFamily:"JetBrains Mono,monospace",color:C.accent,fontSize:14,flex:1,wordBreak:"break-all"}}>{CONTRACT_ADDRESS}</div>
                <Badge color={C.green}>DEPLOYED</Badge>
              </div>
              <div style={{display:"flex",gap:12,marginTop:12,flexWrap:"wrap"}}>
                {[{label:"Protocol Fee",val:"0.5% (50 BPS)"},{label:"Max Merchants",val:"500"},{label:"Compiler",val:"Solidity ^0.8.20"},{label:"Security",val:"ReentrancyGuard + Pausable"}].map(d=>(
                  <div key={d.label} style={{background:"#070B10",borderRadius:6,padding:"10px 14px",flex:"1 1 160px",border:`1px solid ${C.border}`}}>
                    <div style={{fontSize:10,color:C.muted,marginBottom:4}}>{d.label}</div>
                    <div style={{fontFamily:"JetBrains Mono,monospace",color:C.text,fontSize:12}}>{d.val}</div>
                  </div>
                ))}
              </div>
            </div>
            <div style={card}>
              <div style={H2}>Per-Merchant Vault Balances</div>
              <table style={{width:"100%",borderCollapse:"collapse"}}>
                <thead><tr><TH>Merchant</TH><TH>Contract Address</TH><TH>USDT</TH><TH>BTC</TH><TH>ETH</TH><TH>Total USD</TH></tr></thead>
                <tbody>{merchants.map(m=>(
                  <tr key={m.addr}>
                    <TD bold>{m.name}</TD>
                    <TD color={C.accent}>{shortAddr(m.addr)}</TD>
                    <TD color="#26A17B">{fmtN(m.profit*0.6,2)} USDT</TD>
                    <TD color="#F7931A">{(m.profit*0.25/67400).toFixed(6)} BTC</TD>
                    <TD color="#627EEA">{(m.profit*0.15/3520).toFixed(4)} ETH</TD>
                    <TD color={C.gold} bold>{fmtUSD(m.profit)}</TD>
                  </tr>
                ))}</tbody>
              </table>
            </div>
            <div style={{...card,borderColor:`${C.purple}33`}}>
              <div style={H2}>Protocol Fee Reserve</div>
              <div style={{display:"flex",gap:12,flexWrap:"wrap"}}>
                {[{token:"USDT",bal:fmtN(totalFees*0.6,2),color:"#26A17B"},{token:"BTC",bal:(totalFees*0.25/67400).toFixed(6),color:"#F7931A"},{token:"ETH",bal:(totalFees*0.15/3520).toFixed(4),color:"#627EEA"}].map(t=>(
                  <div key={t.token} style={{flex:"1 1 140px",background:"#070B10",borderRadius:8,padding:"12px 16px",border:`1px solid ${C.border}`}}>
                    <div style={{fontSize:10,color:C.muted,marginBottom:6}}>RESERVE</div>
                    <div style={{fontFamily:"JetBrains Mono,monospace",fontSize:18,fontWeight:700,color:t.color}}>{t.bal} {t.token}</div>
                    <button style={{...btn(C.purple,"#fff"),marginTop:8,fontSize:11}} onClick={()=>showToast(`Fee withdrawal initiated for ${t.token}`)}>Withdraw Fees</button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* WITHDRAWALS */}
        {page==="withdrawals"&&(
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            <div style={{fontSize:18,fontWeight:700}}>Withdrawal Queue</div>
            <div style={card}>
              <table style={{width:"100%",borderCollapse:"collapse"}}>
                <thead><tr><TH>ID</TH><TH>Merchant</TH><TH>Token</TH><TH>Amount</TH><TH>Requested</TH><TH>Status</TH><TH>Actions</TH></tr></thead>
                <tbody>{withdrawals.map(w=>(
                  <tr key={w.id}>
                    <TD color={C.muted}>#{w.id}</TD>
                    <TD color={C.accent}>{w.mName}</TD>
                    <TD>{w.token}</TD>
                    <TD bold>{fmtN(w.amount,4)}</TD>
                    <TD color={C.muted}>{timeAgo(w.ts)}</TD>
                    <TD><Badge color={w.status==="pending"?C.gold:w.status==="approved"?C.green:C.red}>{w.status.toUpperCase()}</Badge></TD>
                    <TD>{w.status==="pending"&&<div style={{display:"flex",gap:6}}>
                      <button style={btn("#0A1E14",C.green)} onClick={()=>{setWithdrawals(p=>p.map(x=>x.id===w.id?{...x,status:"approved"}:x));showToast(`Withdrawal #${w.id} approved`);}}>Approve</button>
                      <button style={btn("#1E0A10",C.red)} onClick={()=>{setWithdrawals(p=>p.map(x=>x.id===w.id?{...x,status:"rejected"}:x));showToast(`Withdrawal #${w.id} rejected`,"warn");}}>Reject</button>
                    </div>}</TD>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        )}

        {/* EXCHANGES */}
        {page==="exchanges"&&(
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            <div style={{fontSize:18,fontWeight:700}}>Exchange Registry ({exchanges.length} exchanges)</div>
            <div style={card}>
              <table style={{width:"100%",borderCollapse:"collapse"}}>
                <thead><tr><TH>Exchange</TH><TH>ID</TH><TH>Region</TH><TH>Trades</TH><TH>Volume</TH><TH>Status</TH><TH>Toggle</TH></tr></thead>
                <tbody>{exchanges.map(ex=>(
                  <tr key={ex.id}>
                    <TD>{ex.logo} {ex.name}</TD>
                    <TD color={C.muted}>{ex.id}</TD>
                    <TD color={C.muted}>{ex.region}</TD>
                    <TD>{ex.trades.toLocaleString()}</TD>
                    <TD color={C.gold}>{fmtUSD(ex.vol)}</TD>
                    <TD><Badge color={ex.active?C.green:C.red}>{ex.active?"ACTIVE":"DISABLED"}</Badge></TD>
                    <TD><button style={btn(ex.active?"#1A0A10":"#0A1A10",ex.active?C.red:C.green)} onClick={()=>{setExchanges(p=>p.map(e=>e.id===ex.id?{...e,active:!e.active}:e));showToast(`${ex.name} ${ex.active?"disabled":"enabled"}`);}}>{ex.active?"Disable":"Enable"}</button></TD>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        )}

        {/* TOKENS */}
        {page==="tokens"&&(
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            <div style={{fontSize:18,fontWeight:700}}>Supported Token Contracts</div>
            <div style={{...card,borderColor:`${C.accent}22`}}>
              <div style={H2}>Add Token to Vault Whitelist</div>
              <div style={{display:"flex",gap:10,flexWrap:"wrap"}}>
                <input style={{...input,flex:"1 1 80px"}} placeholder="Symbol" value={newT.symbol} onChange={e=>setNewT(p=>({...p,symbol:e.target.value.toUpperCase()}))}/>
                <input style={{...input,flex:"3 1 240px"}} placeholder="Contract address (0x…)" value={newT.address} onChange={e=>setNewT(p=>({...p,address:e.target.value}))}/>
                <input style={{...input,flex:"1 1 80px"}} placeholder="Decimals" value={newT.decimals} onChange={e=>setNewT(p=>({...p,decimals:e.target.value}))}/>
                <button style={btn(C.accent)} onClick={()=>{
                  if(!newT.symbol||!newT.address)return showToast("Fill all fields","error");
                  setTokenList(p=>[...p,{...newT,decimals:parseInt(newT.decimals),color:"#888"}]);
                  setNewT({symbol:"",address:"",decimals:"18"});
                  showToast(`${newT.symbol} added to vault`);
                }}>Add Token</button>
              </div>
            </div>
            <div style={card}>
              <table style={{width:"100%",borderCollapse:"collapse"}}>
                <thead><tr><TH>Symbol</TH><TH>Contract Address</TH><TH>Decimals</TH><TH>Status</TH></tr></thead>
                <tbody>{tokenList.map(t=>(
                  <tr key={t.address}>
                    <TD color={t.color} bold>{t.symbol}</TD>
                    <TD color={C.accent}>{t.address==="0x0000000000000000000000000000000000000000"?"Native Asset (BNB)":t.address}</TD>
                    <TD color={C.muted}>{t.decimals}</TD>
                    <TD><Badge color={C.green}>SUPPORTED</Badge></TD>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        )}

        {/* CONTRACT */}
        {page==="contract"&&(
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            <div style={{fontSize:18,fontWeight:700}}>Smart Contract · ProfitVaultProtocol.sol</div>
            <div style={{...card,borderColor:`${C.accent}33`}}>
              <div style={H2}>Deployment Info</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                {[
                  {label:"Contract Address",val:CONTRACT_ADDRESS,color:C.accent},
                  {label:"Network",val:"BNB Smart Chain (BSC) · Chain ID 56",color:C.text},
                  {label:"Compiler",val:"Solidity ^0.8.20",color:C.text},
                  {label:"License",val:"MIT",color:C.text},
                  {label:"Protocol Fee",val:"50 BPS (0.50%)",color:C.gold},
                  {label:"Max Merchants",val:"500 contract addresses",color:C.text},
                  {label:"Standards",val:"ERC-20 + OpenZeppelin 5.x",color:C.text},
                  {label:"Security",val:"ReentrancyGuard · Pausable · Ownable",color:C.green},
                ].map(d=>(
                  <div key={d.label} style={{background:"#070B10",borderRadius:8,padding:"12px 16px",border:`1px solid ${C.border}`}}>
                    <div style={{fontSize:10,color:C.muted,marginBottom:4,textTransform:"uppercase",letterSpacing:"0.08em"}}>{d.label}</div>
                    <div style={{fontFamily:"JetBrains Mono,monospace",color:d.color,fontSize:12,wordBreak:"break-all"}}>{d.val}</div>
                  </div>
                ))}
              </div>
            </div>
            <div style={card}>
              <div style={H2}>Core Contract Functions</div>
              <table style={{width:"100%",borderCollapse:"collapse"}}>
                <thead><tr><TH>Function</TH><TH>Access</TH><TH>Description</TH></tr></thead>
                <tbody>{[
                  {fn:"depositProfit()",access:"Operator",color:C.purple,desc:"Deposit ERC-20 spread profit from any exchange into merchant vault"},
                  {fn:"depositNativeProfit()",access:"Operator",color:C.purple,desc:"Deposit native BNB/ETH profit, payable"},
                  {fn:"requestWithdrawal()",access:"Merchant",color:C.green,desc:"Merchant requests withdrawal of vault balance"},
                  {fn:"approveWithdrawal()",access:"Admin",color:C.red,desc:"Admin approves & executes pending withdrawal"},
                  {fn:"rejectWithdrawal()",access:"Admin",color:C.red,desc:"Admin rejects request, returns funds to vault"},
                  {fn:"registerMerchant()",access:"Admin",color:C.red,desc:"Register new merchant address with contract binding"},
                  {fn:"deactivateMerchant()",access:"Admin",color:C.red,desc:"Deactivate merchant and stop profit routing"},
                  {fn:"addExchange()",access:"Admin",color:C.red,desc:"Add new exchange to authorized routing list"},
                  {fn:"addSupportedToken()",access:"Admin",color:C.red,desc:"Whitelist ERC-20 token contract address"},
                  {fn:"setOperator()",access:"Admin",color:C.red,desc:"Grant/revoke bot operator deposit privileges"},
                  {fn:"withdrawFees()",access:"Admin",color:C.red,desc:"Withdraw accumulated 0.5% protocol fee reserve"},
                  {fn:"emergencyPause()",access:"Admin",color:C.red,desc:"Pause all deposits/withdrawals in emergency"},
                ].map(f=>(
                  <tr key={f.fn}><TD color={C.accent}>{f.fn}</TD><TD><Badge color={f.color}>{f.access}</Badge></TD><TD color={C.muted}>{f.desc}</TD></tr>
                ))}</tbody>
              </table>
            </div>
            <div style={card}>
              <div style={H2}>On-Chain Events (Indexed)</div>
              <table style={{width:"100%",borderCollapse:"collapse"}}>
                <thead><tr><TH>Event</TH><TH>Indexed Fields</TH></tr></thead>
                <tbody>{[
                  {ev:"ProfitDeposited",f:"merchant, token, tradeId"},
                  {ev:"ProfitWithdrawn",f:"merchant, token"},
                  {ev:"MerchantRegistered",f:"merchant"},
                  {ev:"WithdrawalRequested",f:"id, merchant"},
                  {ev:"WithdrawalApproved",f:"id"},
                  {ev:"ExchangeRegistered",f:"id, operator"},
                  {ev:"TokenAdded",f:"token"},
                  {ev:"FeeWithdrawn",f:"token"},
                  {ev:"EmergencyPause",f:"by"},
                ].map(e=><tr key={e.ev}><TD color={C.gold}>{e.ev}</TD><TD color={C.muted}>{e.f}</TD></tr>)}</tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
